package com.aivideostudio.app

import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.Locale

private val Ink = Color(0xFF151827)
private val Accent = Color(0xFF7657F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VideoStudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoStudioApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var script by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("हिंदी") }
    var voiceLabel by remember { mutableStateOf("डिफ़ॉल्ट आवाज़") }
    var ttsReady by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("अपना वीडियो चुनकर शुरुआत करें") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            videoUri = uri
            status = "वीडियो लोड हो गया। आप इसे चला सकते हैं।"
            player?.release()
            player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
            }
        }
    }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
            if (result == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
        tts = engine
        onDispose {
            player?.release()
            engine.stop()
            engine.shutdown()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent,
        background = Ink,
        surface = Color(0xFF22263A),
        onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI VIDEO STUDIO", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("Free video creator • Shorts & long videos", fontSize = 11.sp, color = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White),
                actions = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFFD166), modifier = Modifier.padding(end = 16.dp)) }
            )
        }) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    FeaturePill("9:16 Shorts", Modifier.weight(1f))
                    FeaturePill("16:9 YouTube", Modifier.weight(1f))
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF22263A)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Accent)
                            Spacer(Modifier.width(8.dp))
                            Text("वीडियो एडिटर", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        if (player != null) {
                            AndroidView(
                                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                                update = { it.player = player },
                                modifier = Modifier.fillMaxWidth().height(220.dp)
                            )
                        } else {
                            Box(Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF111522), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(42.dp))
                                    Text("आपका वीडियो यहाँ दिखेगा", color = Color.LightGray, fontSize = 13.sp)
                                }
                            }
                        }
                        Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("फोन से वीडियो चुनें")
                        }
                        Text(status, color = Color(0xFFB8C0D9), fontSize = 12.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF22263A)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = Accent)
                            Spacer(Modifier.width(8.dp))
                            Text("AI वॉइस / Text to Speech", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        OutlinedTextField(
                            value = script,
                            onValueChange = { script = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("अपनी कहानी या डायलॉग लिखें") },
                            minLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Accent, unfocusedBorderColor = Color.Gray)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = language == "हिंदी", onClick = { language = "हिंदी"; tts?.language = Locale("hi", "IN") }, label = { Text("हिंदी") })
                            FilterChip(selected = language == "English", onClick = { language = "English"; tts?.language = Locale.US }, label = { Text("English") })
                        }
                        Text("आवाज़: $voiceLabel", color = Color.LightGray, fontSize = 12.sp)
                        Button(
                            onClick = {
                                if (!ttsReady) status = "फोन का Text-to-Speech इंजन तैयार नहीं है। Settings में TTS चालू करें।"
                                else if (script.isBlank()) status = "पहले अपनी कहानी या डायलॉग लिखें।"
                                else {
                                    val result = tts?.setLanguage(if (language == "हिंदी") Locale("hi", "IN") else Locale.US)
                                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                                        status = "$language आवाज़ फोन में उपलब्ध नहीं है। TTS भाषा डाउनलोड करें।"
                                    } else {
                                        tts?.speak(script, TextToSpeech.QUEUE_FLUSH, null, "studio_voice")
                                        status = "आवाज़ चल रही है। यह फोन के मुफ्त TTS इंजन का उपयोग करती है।"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("आवाज़ सुनें")
                        }
                        OutlinedButton(onClick = { tts?.stop(); status = "आवाज़ रोक दी गई।" }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("आवाज़ रोकें")
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF22263A)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("आगे जोड़े जाने वाले एडिटिंग टूल", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        ToolRow(Icons.Default.ContentCut, "Trim / Cut", "वीडियो के हिस्से काटना")
                        ToolRow(Icons.Default.Subtitles, "Auto subtitles", "हिंदी और अंग्रेज़ी कैप्शन")
                        ToolRow(Icons.Default.MusicNote, "Background music", "म्यूजिक और वॉल्यूम कंट्रोल")
                        ToolRow(Icons.Default.Animation, "Cartoon animation", "टेक्स्ट और फोटो से एनिमेशन")
                        ToolRow(Icons.Default.HighQuality, "HD Export", "Shorts और लंबे वीडियो सेव करना")
                        Text("ये एडवांस फीचर इस शुरुआती प्रोजेक्ट में अभी सक्रिय नहीं हैं।", color = Color(0xFFFFD166), fontSize = 11.sp)
                    }
                }
                Text("Version 1.0 • Free starter build", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun FeaturePill(label: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF292343), shape = RoundedCornerShape(50)) {
        Text(label, modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFD9D1FF), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun ToolRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(color = Color(0xFF302B4C), shape = RoundedCornerShape(10.dp)) {
            Icon(icon, contentDescription = null, tint = Color(0xFFB9A9FF), modifier = Modifier.padding(9.dp).size(20.dp))
        }
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = Color.LightGray, fontSize = 11.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("आगे", color = Color.Gray, fontSize = 11.sp)
    }
}
